require "require_all"

require_all "../Pieces"

