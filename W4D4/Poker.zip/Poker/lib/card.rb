class Card
    attr_reader :face_value, :suit
    def initialize(value, suit)
        @face_value = value
        @suit = suit
    end

end