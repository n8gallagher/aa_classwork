require_relative '../lib/card'


describe "Card" do
    card1 = Card.new(:A, :Spade)
    describe "Card#initialize" do
        it "should initialize a Card instance" do
            expect(card1).to be_a_kind_of(Card)
        end

        it "should contain a face value" do
            expect(card1.face_value).to eq(:A)
        end

        it "should contain a suit" do
            expect(card1.suit).to eq(:Spade)
        end

    end

end