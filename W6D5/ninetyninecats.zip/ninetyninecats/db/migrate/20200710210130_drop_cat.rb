class DropCat < ActiveRecord::Migration[5.2]
  def change
    drop_table :cat
  end
end
