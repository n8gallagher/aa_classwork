// TODO: myCurry

Function.prototype.myCurry = function(numArgs) {
  let args = [];
  let that = this;

  function _curried(arg) {
    args.push(arg);

    if(args.length === numArgs) {
      return that.apply(null, args);
    } else {
      return _curried;
    }
  };

  return _curried;
}

sum.myCurry(3)(5,7,8);