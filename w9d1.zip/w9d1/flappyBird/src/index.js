import FlappyBird from './game';

const canvas = document.getElementById('bird-game');
let bird = new FlappyBird(canvas);
bird.restart();